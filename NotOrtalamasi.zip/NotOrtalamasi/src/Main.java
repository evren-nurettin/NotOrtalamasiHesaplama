import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        int mat, fizik, kimya, turkce, tarih, muzik;
        System.out.println("------Öğrenci Not Ortalaması Hesaplama Uygulaması------");
        System.out.println();
        System.out.print("Matematik Notunu Giriniz: ");
        mat = scn.nextInt();

        System.out.print("Fizik Notunu Giriniz: ");
        fizik = scn.nextInt();

        System.out.print("Kimya Notunu Giriniz: ");
        kimya = scn.nextInt();

        System.out.print("Türkçe Notunu Giriniz: ");
        turkce = scn.nextInt();

        System.out.print("Tarih Notunu Giriniz: ");
        tarih = scn.nextInt();

        System.out.print("Müzik Notunu Giriniz: ");
        muzik = scn.nextInt();

        double ortalama = (mat+fizik+kimya+turkce+tarih+muzik)/6;
        System.out.println("Not Ortalamanız: "+ ortalama);
        String netice = ortalama>60.0? "Sınıfı Geçtiniz.": "Sınıfta Kaldınız.";
        System.out.println(netice);


    }
}